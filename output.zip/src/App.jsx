import { useState, useEffect } from 'react';
import Memory from './Memory'

const contents = [
  <>
    <h1>
      プログラミング基礎 成果発表会
    </h1>
  </>,
  <>
    <h3>My name is もりしま あきひと</h3>
    <p>
      昭和時代の皇太子殿下にちなんで付けられた名前なので<br />
      下の名前で呼ばれるのはDIGがはじめてでびっくり
    </p>
    <img src="heisei.png" className="photo"></img>
  </>,
  <>
    <p>
      入社後しばらくは生産技術に従事<br />
      中国天津や長春にも出張
    </p>
    <img src="china.jpg" className="photo"></img>
  </>,
  <>
    <p>
      その後、生技部門全体の投資を管理する部署に異動<br />
      当時はBIツールはなかったのでExcelマクロを習得
    </p>
  </>,
  <>
    <p>
      ある日、自部署にある人物が異動してきた<br />
      その人の名は<b>Pepper</b><br />
      Pepperアプリを作るためPythonを習得
    </p>
    <img src="robot.png" className="photo"></img>
  </>,
  <>
    <p>
      現在は社内のデジタル化を推進する部署にて<br />
      現場さんの困りごとに対応<br />
      Power AppsやPythonやExcelマクロでアプリを作る
    </p>
  </>,
  <>
    <p>
      PythonでWebアプリを作ったとき、<br />
      「これってバックエンドのPythonよりも<br />
      フロントエンドのJavaScriptのほうが<br />
      メインなんじゃね？」と思いはじめる
    </p>
    <img src="agribecky.png" className="photo"></img>
  </>,
  <>
    <p>
      何期めかのDIGの基礎コースで、ある受講者が<br />
      「PythonアプリをNode.js+Expressで作りなおしました」と<br />
      発表していたのを見て自分もNode,jsの勉強をはじめる<br />
    </p>
    <img src="eureka.png" className="photo"></img>
  </>,
  <>
    <p>
      というタイミングでDIGを受講することにした
    </p>
  </>,
  <>
    <p>
      DIGでは、自習では気づかなかった事例を多く知ることができました<br />
      今後も役立てていきます（主にプライベートで）<br />
      ありがとうございました
    </p>
      <img src="thankyou.png" className="photo"></img>
  </>,
  <>
    <div className="de">
      で、
    </div>
  </>,
  <>
    <p>
      我が卒業制作発表はここからが本番です
    </p>
  </>,
  <>
    <p>
      その名も
    </p>
  </>,
  <>
    <h1>
      ドラ鉄ゲッサー
    </h1>
    <h2>
      <a href="https://doratetuguessr.onrender.com/" target="_blank">https://doratetuguessr.onrender.com/</a>
    </h2>
    <p>
      皆さんも遊んでみてください
    </p>
  </>
];

function App() {
  const [count, setCount] = useState(0);
  const ratio = count / (contents.length - 1);
  const value = Math.round(255 * (1 - ratio));
  document.body.style.backgroundColor = `rgb(${value}, ${value}, ${value})`;
  const size = 20 + ratio * 30;

  return (
    <div className="MainContainer">
      <div className='upper'>
        <div>
        </div>
        <div>
          <div className='ball light glow' style={{ width:`${size}px`, height:`${size}px`, fontSize:`${size}px` }}>も</div>
          <div className='ball light glow' style={{ width:`${size}px`, height:`${size}px`, fontSize:`${size}px` }}>り</div>
          <div className='ball light glow' style={{ width:`${size}px`, height:`${size}px`, fontSize:`${size}px` }}>し</div>
          <div className='ball light glow' style={{ width:`${size}px`, height:`${size}px`, fontSize:`${size}px` }}>ま</div>
        </div>
        <div className="button_container">
          <div className="button" onClick={() => setCount((count) => Math.max(0, count - 1))}> ≪ </div>
          <div className="button" onClick={() => setCount((count) => 0)}> ・ </div>
          <div className="button" onClick={() => setCount((count) => Math.min(count + 1, contents.length-1))}> ≫ </div>
        </div>
      </div>
      <div className="lower">
        <Memory count={count} content={contents[count]} />
      </div>
    </div>
  );
}

export default App
