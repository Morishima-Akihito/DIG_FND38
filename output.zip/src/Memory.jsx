import { useLayoutEffect, useRef, useState } from 'react';

function Memory({ count, content }) {
  const divRef = useRef(null);
  const [position, setPosition] = useState({ top: 0, left: 0 });

  useLayoutEffect(() => {
    const div = divRef.current;
    if (!div) return;

    window.requestAnimationFrame(() => {
      const divRect = div.getBoundingClientRect();
      const parent = div.parentElement;
      const parentRect = parent.getBoundingClientRect();

      const parentStyle = window.getComputedStyle(parent);
      const paddingLeft = parseInt(parentStyle.paddingLeft, 10);
      const paddingRight = parseInt(parentStyle.paddingRight, 10);

      const minLeft = paddingLeft;
      const maxLeft = parentRect.width - divRect.width - paddingRight;

      const left = (count === 0)
        ? (minLeft + maxLeft) / 2
        : Math.floor(Math.random() * (maxLeft - minLeft + 1)) + minLeft;

      const maxTop = parentRect.height - divRect.height;
      const top = (count === 0) ? (maxTop / 2) * 0.8 : Math.floor(Math.random() * maxTop);

      setPosition({ top, left });
    });
  }, [content]);


  return (
    <div
      className="memory"
      ref={divRef}
      style={{
        position: 'absolute',
        top: position.top,
        left: position.left,
      }}
    >
      {content}
    </div>
  );
}

export default Memory;
